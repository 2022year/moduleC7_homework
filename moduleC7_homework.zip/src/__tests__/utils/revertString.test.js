import { revertString } from "../../utils/revertString.js";

describe("tests for revertString function", () => {
  const s1 = "abc";   const s1r = "cba";
  const s2 = "123";   const s2r = "321";
  it("should reverse string", () => expect(revertString(s1)).toBe(s1r));
  it("should reverse string", () => expect(revertString(s2)).toBe(s2r));
});
